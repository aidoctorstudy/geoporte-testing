/**
 * Brand mark — the 8-point chrome "Superconscious" star.
 *
 * The single source of truth for the logo geometry, shared by the generated
 * icons (`app/icon.tsx`, `app/apple-icon.tsx`) and share images
 * (`app/opengraph-image.tsx`, `app/twitter-image.tsx`). Mirrors
 * `public/assets/showreel/star.svg` (viewBox 0 0 523 523).
 */
export const STAR_VIEWBOX = "0 0 523 523";

export const STAR_PATH =
  "M250.168 7.83547C254.034 -2.61195 268.81 -2.61197 272.676 7.83545L296.638 72.5928C322.973 143.76 379.083 199.871 450.25 226.205L515.008 250.167C525.455 254.033 525.455 268.81 515.008 272.676L450.251 296.638C379.084 322.972 322.973 379.083 296.638 450.25L272.676 515.007C268.81 525.455 254.034 525.455 250.168 515.007L226.205 450.25C199.871 379.083 143.76 322.972 72.5933 296.638L7.83596 272.676C-2.61146 268.81 -2.61148 254.033 7.83594 250.167L72.5932 226.205C143.76 199.871 199.871 143.76 226.205 72.5928L250.168 7.83547Z";

/** Brand palette for generated imagery (kept in sync with `globals.css`). */
export const BRAND = {
  background: "#000000",
  paper: "#f5f1ec",
  violet: "#9a73f0",
  violetDeep: "#34146e",
} as const;
